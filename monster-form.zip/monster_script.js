

        // JavaScript to format phone number as XXX XXX XXXX
        document.addEventListener("DOMContentLoaded", function() {
            var phoneInput = document.getElementById('phone_number');
            phoneInput.addEventListener('input', function(event) {
                var phoneNumber = event.target.value.replace(/\D/g, '');
                var formattedPhoneNumber = formatPhoneNumber(phoneNumber);
                event.target.value = formattedPhoneNumber;
            });
            
            function formatPhoneNumber(phoneNumber) {
                var formattedNumber = '';
                if (phoneNumber.length > 3) {
                    formattedNumber += phoneNumber.substring(0, 3) + ' ';
                    phoneNumber = phoneNumber.substring(3);
                }
                if (phoneNumber.length > 3) {
                    formattedNumber += phoneNumber.substring(0, 3) + ' ';
                    phoneNumber = phoneNumber.substring(3);
                }
                formattedNumber += phoneNumber;
                return formattedNumber;
            }
        });


        // JavaScript for Thank you text
        document.addEventListener("DOMContentLoaded", function() {
            
            var thankYou = document.getElementById('thank-you');
            var form = document.getElementById('custom-contact-form');
            if (thankYou) {
                

                form.addEventListener('submit', function(event) {
                   

                    // Hide the form and show the "Thank you" message
                    form.style.display = 'none';
                    thankYou.style.display = 'block';
                });
                
            }
        });

    

