<?php
/*
Plugin Name: Leads
Description: Simple contact form plugin for WordPress with database storage and admin page.
Version: 1.0
Author: Edsel Rey Tampos
*/
// Include the main plugin file
require_once dirname(__FILE__) . '/monster_form.php';


// Activation hook
function leads_installer_activation() {
    // Call the function to create the database table
    custom_contact_form_create_table();
}
register_activation_hook(__FILE__, 'leads_installer_activation');
