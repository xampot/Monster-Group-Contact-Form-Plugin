<?php
function my_plugin_enqueue_scripts() {
    // Enqueue jQuery from CDN
    wp_enqueue_script('jquery', 'https://code.jquery.com/jquery-3.6.0.min.js', array(), '3.6.0', true);

}
add_action('wp_enqueue_scripts', 'my_plugin_enqueue_scripts');
// Create table for storing form submissions
function custom_contact_form_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_form_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        email varchar(100) NOT NULL,
        phone_number varchar(100) NOT NULL,
        service_required varchar(100) NOT NULL,
        submission_time datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";


    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}


// Add shortcode for displaying the contact form
function custom_contact_form_shortcode() {
    ob_start(); ?>
   
    <form id="custom-contact-form" method="post">
            <h3>We'd love to help, leave us your details and we'll be in touch.</h3>
            <p>
                <label for="name">Name</label><br>
                <input type="text" id="name" name="name" required>
            </p>
            <p>
                <label for="email">Email</label><br>
                <input type="email" id="email" name="email" required>
            </p>
            <p>
                <label for="phone_number">Phone number</label><br> 
                <input type="text" id="phone_number" name="phone_number"  maxlength="12" required>
            </p>
            <p>
                <label for="service_required">Service required</label><br>  
                <input type="text" id="service_required" name="service_required" required>
            </p>
            <p>
                <input class="submit" type="submit" name="submit" value="Submit">
            </p>
    </form>
    
    <div id="thank-you" style="display: none;">
        <p>Thank you! We will contact you as soon as possible.</p>
    </div>

    <?php
    return ob_get_clean();
}
add_shortcode('custom_contact_form', 'custom_contact_form_shortcode');

// Process form submission and save to database
function custom_contact_form_process() {
    // Check if the form has been submitted and if the "submit" field is set
    if (isset($_POST['submit']) && !isset($_POST['form_submitted'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'contact_form_submissions';

        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone_number = preg_replace('/[^0-9]/', '', $_POST['phone_number']);  
        $service_required = sanitize_text_field($_POST['service_required']);

        $wpdb->insert(
            $table_name,
            array(
                'name' => $name,
                'email' => $email,
                'phone_number' => $phone_number, 
                'service_required' => $service_required  
            )
        );

        // Introduce a delay of 5 sec 
        sleep(5); // 

        // Redirect back to the form page after submission
        wp_redirect(add_query_arg('form_submitted', 'true', $_SERVER['REQUEST_URI']));
        exit;
    }
}




add_action('init', 'custom_contact_form_process');

// Add custom admin menu for viewing form submissions
function custom_contact_form_admin_menu() {
    add_menu_page(
        'Contact Form Submissions',
        'Leads',
        'manage_options',
        'contact-form-submissions',
        'custom_contact_form_admin_page'
    );
}
add_action('admin_menu', 'custom_contact_form_admin_menu');

// Display form submissions in a table on the admin page
function custom_contact_form_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'contact_form_submissions';
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submission_time DESC;");
    
    echo '<div class="wrap">';
    echo '<h2>Leads</h2>';

    // Display the shortcode
    echo '<p>Shortcode for the contact form: <code>[custom_contact_form]</code></p>';
    
    if (!empty($submissions)) {
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Service required</th><th>Date submitted</th></tr></thead>';
        echo '<tbody>';
        
        foreach ($submissions as $submission) {
            echo '<tr>';
            echo '<td>' . esc_html($submission->name) . '</td>';
            echo '<td>' . esc_html($submission->email) . '</td>';
            echo '<td>' . esc_html($submission->phone_number) . '</td>';
            echo '<td>' . esc_html($submission->service_required) . '</td>';
            echo '<td>' . esc_html($submission->submission_time) . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No form submissions yet.</p>';
    }
    
    echo '</div>';
}
 

// Enqueue CSS file
function custom_contact_form_enqueue_styles() {
    wp_enqueue_style('custom-contact-form-style', plugins_url('monster_css.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'custom_contact_form_enqueue_styles');


// Enqueue JavaScript file
function custom_contact_form_enqueue_scripts() {
    wp_enqueue_script('custom-contact-form-script', plugins_url('monster_script.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'custom_contact_form_enqueue_scripts');

?>




